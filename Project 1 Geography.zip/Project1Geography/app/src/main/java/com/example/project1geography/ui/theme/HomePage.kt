package com.example.project1geography.ui.theme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun HomePage(navController: NavHostController) {
    Column(
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()
    ) {
        Button(onClick = {
            navController.navigate(route = "GuessCountry")
        }) {
            Text(text = "Guess the Country", fontSize = 40.sp)
        }
        Button(onClick = {
            navController.navigate(route = "Guess Hints")
        })
        {
            Text(text = "Guess Hints", fontSize = 40.sp)
        }
        Button(onClick = {}) {
            Text(text = "Guess the Flag", fontSize = 40.sp)
        }
        Button(onClick = {}) {
            Text(text = "Advanced Level", fontSize = 40.sp)

        }
    }
}
