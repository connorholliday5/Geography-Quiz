package com.example.project1geography

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.geographyquix.GuessCountry
import com.example.project1geography.ui.theme.HomePage

@Composable
fun Nav(){

    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "HomePage"){

        composable(route = "HomePage"){
            HomePage(navController)
        }
        composable(route = "GuessCountry"){
            GuessCountry(navController)
        }
        composable(route = "Guess Hints"){
            GuessHints(navController)
        }
    }
}


